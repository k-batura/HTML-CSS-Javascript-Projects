/* Task 1 - write your code here */
function lightOne()
{
document.getElementById('light').src='light_1.jpg';
}

function lightTwo()
{
document.getElementById('light').src='light_2.jpg';
}

function lightThree()
{
document.getElementById('light').src='light_3.jpg';
}

function lightFour()
{
document.getElementById('light').src='light_4.jpg';
}

function lightFive()
{
document.getElementById('light').src='light_5.jpg';
}
