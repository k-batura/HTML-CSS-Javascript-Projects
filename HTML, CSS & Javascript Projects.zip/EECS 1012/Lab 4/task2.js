
function getNumber(value)
{
  var display = document.getElementById("mydata");
  display.innerHTML = "Result = " + value;
}
